# Android Research Agent V3

V3 is the first real Agent Loop foundation.

## Included
- Agent loop with bounded iterations.
- Device capability detection.
- Local AI provider abstraction.
- Runtime probe for Android ML Kit GenAI Prompt API.
- Offline deterministic planner fallback.
- Secure-by-design Web Provider interface.
- Accessibility action engine:
  - open URL
  - read visible screen
  - click text
  - type into focused editable
  - scroll
  - back
- Local memory for the latest report.
- GitHub Actions build.

## Local AI reality

The ML Kit Prompt API supports Android API 26+ and exposes model availability states such as AVAILABLE, DOWNLOADABLE and UNAVAILABLE. A local model is not guaranteed on every phone.

The app therefore does not crash when local AI is unavailable; it falls back to deterministic planning.

For broader device coverage, llama.cpp can be integrated with a GGUF model as a native backend. Do not bundle a huge model into the APK; download/import it separately and choose based on detected RAM/storage.

## Online research

The Android app never contains a provider API key. Put keys on the backend and configure the backend URL in the app.

## Build

Push this repository to GitHub and run:
Actions -> Build Android V3 -> Run workflow

## Security

Accessibility is powerful. The V3 executor is deliberately limited to explicit actions. A production version should add:
- user confirmation for risky actions
- domain allowlists
- action timeouts
- loop limits
- audit logs
- secure backend authentication

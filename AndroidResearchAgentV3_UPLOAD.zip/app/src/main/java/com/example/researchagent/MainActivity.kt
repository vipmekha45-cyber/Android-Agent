package com.example.researchagent

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val task = findViewById<EditText>(R.id.taskInput)
        val backend = findViewById<EditText>(R.id.backendInput)
        val status = findViewById<TextView>(R.id.status)
        val output = findViewById<TextView>(R.id.output)
        val caps = findViewById<TextView>(R.id.capabilities)

        val capability = DeviceCapabilityDetector.detect(this)
        caps.text = capability.toDisplayString()

        findViewById<Button>(R.id.settingsButton).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.runButton).setOnClickListener {
            val prompt = task.text.toString().trim()
            if (prompt.isBlank()) {
                status.text = "الحالة: اكتب المهمة أولاً."
                return@setOnClickListener
            }
            status.text = "الحالة: Agent Loop يعمل..."
            output.text = ""

            Thread {
                val result = AgentLoop.run(
                    context = this,
                    task = prompt,
                    backendUrl = backend.text.toString().trim().ifBlank { null }
                )
                runOnUiThread {
                    status.text = "الحالة: ${result.status}"
                    output.text = result.text
                }
            }.start()
        }
    }
}

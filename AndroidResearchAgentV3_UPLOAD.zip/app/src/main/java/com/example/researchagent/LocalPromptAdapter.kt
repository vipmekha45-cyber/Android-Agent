package com.example.researchagent

import android.util.Log

/**
 * Reflection bridge for the ML Kit GenAI Prompt API.
 *
 * Why reflection?
 * The local-AI runtime can differ by device/OS/AICore availability.
 * This adapter probes the API at runtime instead of crashing the app when
 * the local model is unavailable.
 *
 * For supported devices, the official Prompt API exposes:
 * Generation.getClient()
 * checkStatus()
 * download()
 * generateContent(...)
 *
 * See Android Developers Prompt API documentation.
 */
object LocalPromptAdapter {
    fun isApiPresent(): Boolean = try {
        Class.forName("com.google.mlkit.genai.prompt.Generation")
        true
    } catch (_: Throwable) { false }

    fun availabilityLabel(): String {
        return if (isApiPresent()) "Prompt API library present; runtime model checked on use"
        else "Prompt API unavailable in this build"
    }

    fun safeProbe(): String {
        return try {
            val generation = Class.forName("com.google.mlkit.genai.prompt.Generation")
            val getClient = generation.getMethod("getClient")
            val client = getClient.invoke(null)
            val check = client.javaClass.methods.firstOrNull { it.name == "checkStatus" }
            if (check != null) "Local Prompt API client detected" else "Local API detected"
        } catch (e: Throwable) {
            Log.d("LocalPromptAdapter", "probe failed", e)
            "Local Prompt API not available"
        }
    }
}

package com.example.researchagent

import android.content.Context
import org.json.JSONObject

object LocalAiProvider {
    fun plan(
        task: String,
        iteration: Int,
        notes: List<String>,
        capabilities: DeviceCapabilities
    ): AgentDecision {
        // Deterministic planner first: safe and works without an LLM.
        // The on-device Gemini Nano adapter can be enabled when the runtime/model
        // is available; see LocalPromptAdapter for the reflection bridge.
        if (iteration > 4 && notes.any { it.startsWith("WEB_ERROR") }) {
            return AgentDecision(AgentAction.FINISH)
        }
        if (notes.any { it.startsWith("WEB_RESULT:") }) {
            return AgentDecision(AgentAction.FINISH)
        }
        if (task.contains("بحث", true) || task.contains("ابحث", true) ||
            task.contains("research", true) || task.contains("compare", true)) {
            return AgentDecision(AgentAction.WEB_RESEARCH)
        }
        return AgentDecision(AgentAction.READ_SCREEN)
    }

    fun finalizeReport(task: String, notes: String): String {
        return """
        التقرير النهائي

        المهمة:
        $task

        نتائج الـAgent:
        $notes

        الحالة:
        تم تنفيذ Agent Loop. إذا لم يوجد Web Backend، فالمعلومات الحديثة من الإنترنت
        لا يمكن جلبها في وضع Offline.
        """.trimIndent()
    }
}

package com.example.researchagent

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        try {
            setContentView(R.layout.activity_main)

            val task = findViewById<EditText>(R.id.taskInput)
            val backend = findViewById<EditText>(R.id.backendInput)
            val status = findViewById<TextView>(R.id.status)
            val output = findViewById<TextView>(R.id.output)
            val caps = findViewById<TextView>(R.id.capabilities)

            try {
                caps.text = DeviceCapabilityDetector.detect(this).toDisplayString()
            } catch (e: Throwable) {
                caps.text = "تعذر قراءة قدرات الجهاز."
            }

            findViewById<Button>(R.id.settingsButton).setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                } catch (e: Throwable) {
                    status.text = "تعذر فتح إعدادات Accessibility."
                }
            }

            findViewById<Button>(R.id.runButton).setOnClickListener {
                val prompt = task.text.toString().trim()
                if (prompt.isBlank()) {
                    status.text = "الحالة: اكتب المهمة أولاً."
                    return@setOnClickListener
                }

                status.text = "الحالة: Agent Loop يعمل..."
                output.text = ""

                Thread {
                    val result = try {
                        AgentLoop.run(
                            context = applicationContext,
                            task = prompt,
                            backendUrl = backend.text.toString().trim().ifBlank { null }
                        )
                    } catch (e: Throwable) {
                        AgentResult(
                            "error",
                            "حدث خطأ أثناء تشغيل الوكيل:\n${e.javaClass.simpleName}: ${e.message ?: "unknown"}"
                        )
                    }

                    runOnUiThread {
                        status.text = "الحالة: ${result.status}"
                        output.text = result.text
                    }
                }.start()
            }
        } catch (e: Throwable) {
            showFatalError(e)
        }
    }

    private fun showFatalError(e: Throwable) {
        try {
            AlertDialog.Builder(this)
                .setTitle("Research Agent V3.1")
                .setMessage(
                    "حدث خطأ عند تشغيل التطبيق.\n\n" +
                    "${e.javaClass.simpleName}: ${e.message ?: "unknown"}"
                )
                .setPositiveButton("إغلاق", null)
                .show()
        } catch (_: Throwable) {
            finish()
        }
    }
}

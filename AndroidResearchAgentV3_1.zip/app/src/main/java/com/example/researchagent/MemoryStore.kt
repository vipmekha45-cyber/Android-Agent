package com.example.researchagent

import android.content.Context

class MemoryStore(context: Context) {
    private val prefs = context.getSharedPreferences("agent_memory", Context.MODE_PRIVATE)

    fun save(task: String, report: String) {
        prefs.edit().putString("last_task", task).putString("last_report", report).apply()
    }

    fun lastReport(): String? = prefs.getString("last_report", null)
}

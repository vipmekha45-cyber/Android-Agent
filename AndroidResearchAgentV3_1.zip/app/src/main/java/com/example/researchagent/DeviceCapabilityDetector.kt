package com.example.researchagent

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.StatFs
import java.io.File

data class DeviceCapabilities(
    val api: Int,
    val abi: String,
    val ramMb: Long,
    val freeStorageMb: Long,
    val accessibility: Boolean,
    val localAiCandidate: Boolean
) {
    fun toDisplayString() = """
        Device: Android $api • $abi
        RAM: ${ramMb} MB • Free storage: ${freeStorageMb} MB
        Accessibility: ${if (accessibility) "available" else "not connected"}
        Local AI candidate: ${if (localAiCandidate) "yes" else "conservative"}
    """.trimIndent()
}

object DeviceCapabilityDetector {
    fun detect(context: Context): DeviceCapabilities {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        val stat = StatFs(Environment.getDataDirectory().path)
        val freeMb = stat.availableBytes / (1024 * 1024)
        val ramMb = info.totalMem / (1024 * 1024)
        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown"
        val accessibility = AgentAccessibilityService.instance != null
        val localCandidate = Build.VERSION.SDK_INT >= 26 && ramMb >= 3000 && freeMb >= 2048
        return DeviceCapabilities(Build.VERSION.SDK_INT, abi, ramMb, freeMb, accessibility, localCandidate)
    }
}

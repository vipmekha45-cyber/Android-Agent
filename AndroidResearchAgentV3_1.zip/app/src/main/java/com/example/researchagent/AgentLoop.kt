package com.example.researchagent

import android.content.Context

data class AgentResult(val status: String, val text: String)

object AgentLoop {
    fun run(context: Context, task: String, backendUrl: String?): AgentResult {
        val caps = DeviceCapabilityDetector.detect(context)
        val memory = MemoryStore(context)

        var state = AgentState(
            task = task,
            iteration = 0,
            maxIterations = 6,
            notes = mutableListOf()
        )

        while (state.iteration < state.maxIterations) {
            state = state.copy(iteration = state.iteration + 1)

            val decision = LocalAiProvider.plan(
                task = state.task,
                iteration = state.iteration,
                notes = state.notes,
                capabilities = caps
            )

            when (decision.action) {
                AgentAction.FINISH -> {
                    val report = LocalAiProvider.finalizeReport(
                        task, state.notes.joinToString("\n")
                    )
                    memory.save(task, report)
                    return AgentResult("finished", report)
                }

                AgentAction.WEB_RESEARCH -> {
                    if (backendUrl.isNullOrBlank()) {
                        state.notes.add("Web requested but no backend URL is configured.")
                        state.notes.add("Offline limitation: fresh web research unavailable.")
                        val report = LocalAiProvider.finalizeReport(task, state.notes.joinToString("\n"))
                        memory.save(task, report)
                        return AgentResult("offline", report)
                    }

                    val result = WebProvider.research(backendUrl, task, state.notes)
                    if (result.ok) state.notes.add(result.text)
                    else state.notes.add("WEB_ERROR: ${result.text}")
                }

                AgentAction.OPEN_URL -> {
                    val url = decision.argument
                    val ok = AgentAccessibilityService.instance?.openUrl(url) == true
                    state.notes.add(if (ok) "Opened: $url" else "Could not open URL: $url")
                }

                AgentAction.READ_SCREEN -> {
                    val text = AgentAccessibilityService.instance?.readVisibleText()
                    state.notes.add(text ?: "Accessibility is not connected.")
                }

                AgentAction.SCROLL -> {
                    val ok = AgentAccessibilityService.instance?.scrollForward() == true
                    state.notes.add("scroll=$ok")
                }

                AgentAction.BACK -> {
                    val ok = AgentAccessibilityService.instance?.goBack() == true
                    state.notes.add("back=$ok")
                }
            }
        }

        val report = LocalAiProvider.finalizeReport(task, state.notes.joinToString("\n"))
        memory.save(task, report)
        return AgentResult("max iterations reached", report)
    }
}

enum class AgentAction { WEB_RESEARCH, OPEN_URL, READ_SCREEN, SCROLL, BACK, FINISH }

data class AgentDecision(val action: AgentAction, val argument: String = "")

data class AgentState(
    val task: String,
    val iteration: Int,
    val maxIterations: Int,
    val notes: MutableList<String>
)

package com.example.researchagent

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class WebProviderResult(val ok: Boolean, val text: String)

object WebProvider {
    fun research(baseUrl: String, task: String, notes: List<String>): WebProviderResult {
        return try {
            val endpoint = URL(baseUrl.trimEnd('/') + "/research")
            val body = JSONObject()
                .put("task", task)
                .put("notes", notes.joinToString("\n"))
                .put("language", "ar")
                .toString()

            val c = endpoint.openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 120000
            c.setRequestProperty("Content-Type", "application/json")
            c.doOutput = true
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

            val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
            val raw = stream.bufferedReader().use { it.readText() }
            if (c.responseCode !in 200..299) WebProviderResult(false, raw)
            else WebProviderResult(true, "WEB_RESULT:\n" + JSONObject(raw).optString("report", raw))
        } catch (e: Exception) {
            WebProviderResult(false, e.message ?: e.toString())
        }
    }
}

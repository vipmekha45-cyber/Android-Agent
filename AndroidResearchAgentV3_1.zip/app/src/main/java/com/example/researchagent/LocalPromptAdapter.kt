package com.example.researchagent

/**
 * V3.1 stability build.
 *
 * The optional on-device Prompt API is intentionally not loaded in this build.
 * This prevents a device-specific GenAI/AICore initialization issue from
 * crashing the launcher activity. The agent still supports the deterministic
 * planner and online backend path.
 */
object LocalPromptAdapter {
    fun isApiPresent(): Boolean = false

    fun availabilityLabel(): String =
        "Local AI adapter disabled in V3.1 stability build"

    fun safeProbe(): String =
        "Local AI is not loaded in this stability build"
}

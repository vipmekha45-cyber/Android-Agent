# Android Research Agent V3.1 — Stability Build

This release is a stability-focused rebuild of V3.

Changes:
- Removed the optional ML Kit GenAI Prompt dependency from the launcher build.
- Uses the platform `Activity` instead of AppCompat for a smaller startup surface.
- Added defensive error handling around startup and agent execution.
- Accessibility service is explicitly exported for system binding compatibility.
- Version is 3.1 / versionCode 31.

V3.1 keeps the deterministic agent loop and optional online backend path.
The full browser/Chrome executor is planned for the next release.

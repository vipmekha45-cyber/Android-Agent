# V3 Web Provider contract

Android calls:

POST /research
Content-Type: application/json

{
  "task": "بحث المستخدم",
  "notes": "ملاحظات Agent Loop",
  "language": "ar"
}

Return:

{
  "report": "تقرير نهائي مع المصادر"
}

Keep API keys only on the server.

Recommended server responsibilities:
1. Receive task.
2. Call your preferred web-capable model/search provider.
3. Search multiple sources.
4. Extract facts and URLs.
5. Verify conflicts.
6. Return a concise Arabic report with source URLs.
7. Apply authentication and rate limiting.

Do not embed provider API keys in the Android APK.
